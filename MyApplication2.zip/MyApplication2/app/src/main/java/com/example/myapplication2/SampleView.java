package com.example.myapplication2;

import android.content.Context;
import android.view.View;

public class SampleView extends View {

    public SampleView(Context context) {
        super(context);
    }
}
